# SA Calculator v98.48 — Video-led layout and behavior correction

Release: `1.98.48-v98.48`  
Android versionCode: `1098048`

## Main corrections
- Scientific Calculator: all five numeric keypad rows and memory row remain visible; function bank scrolls independently.
- Scientific expression editor: unchanged values no longer reset the cursor; long expressions keep the insertion point visible.
- Tools: stable two-column grid; search and category filters occupy their own non-overlapping rows.
- Currency rate metadata: compact, readable typography and spacing.
- Android web bundle and Service Worker use the v98.48 stylesheet/cache identity.

## Build and test
- `npm test`
- `npm run build:web`
- Android APK build runs in the supplied GitHub Actions workflow.

The source ZIP does not contain a signed APK. Physical-device frame-rate, touch-latency, memory and battery measurements still require an Android device.
