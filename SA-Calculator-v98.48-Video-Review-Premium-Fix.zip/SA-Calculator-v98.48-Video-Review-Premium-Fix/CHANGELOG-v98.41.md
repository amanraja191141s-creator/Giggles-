# SA Calculator v98.41 — 20+ app benchmark and actual-DOM UI correction

## Root-cause corrections
- Closed drawer is explicitly hidden and non-interactive; its focused search field cannot leak a clipped blue border into the calculator header.
- Skip link is clipped and borderless for touch focus, while keyboard-visible focus remains available.
- Calculator display overrides now target the actual markup classes `.calc-display`, `.calc-expression-row`, `.calc-preview-row`, `.calc-expression-text`, and `.calc-preview-val`, rather than relying only on legacy element IDs. All display edges and pseudo-elements are removed.
- Keypad receives the remaining flex height; compact navigation uses the actual `#bottom-navigation` ID and bounded tab heights.
- Currency and Unit Converter keypad utility labels render as icons while TalkBack aria-labels and action semantics remain.

## Compatibility
- Existing 18 screen IDs, scientific engine, calculation handlers, converter logic, currency rate provider, history, favorites, themes and settings are preserved.
- New cache identity ensures the v98.41 CSS/HTML is not served from the previous v98.40 service-worker cache.
- Build script requires the new stylesheet and copies it to the Android web bundle.
