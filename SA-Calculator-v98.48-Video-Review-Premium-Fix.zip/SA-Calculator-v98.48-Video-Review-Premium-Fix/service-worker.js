'use strict';
const CACHE='sa-calculator-v98-48-video-layout-fix';
// CSS source layers are consolidated into ./assets/css/app.css at build time: assets/css/rebuild-v98.32.css, assets/css/rebuild-v98.33.css, assets/css/rebuild-v98.35.css, assets/css/rebuild-v98.37.css, assets/css/rebuild-v98.38.css, assets/css/rebuild-v98.39.css, assets/css/rebuild-v98.40.css, assets/css/rebuild-v98.41.css, assets/css/rebuild-v98.44.css, assets/css/rebuild-v98.45.css, assets/css/rebuild-v98.46.css, assets/css/rebuild-v98.47.css, assets/css/rebuild-v98.48.css.
const ASSETS=['./','./index.html','./manifest.webmanifest','./assets/css/app.css','./assets/js/theme-bootstrap.js','./assets/js/localization.js','./assets/js/currency-localized-names.js','./assets/js/app.js','./assets/brand/sa-calculator-icon.png','./assets/brand/sa-calculator-192.png','./assets/brand/sa-calculator-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>(key.startsWith('sumaire-')||key.startsWith('sa-calculator-'))&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET')return;
 const url=new URL(req.url);if(url.origin!==self.location.origin)return;
 // Never cache API responses: currency data must pass provider freshness validation on every refresh.
 if(url.pathname.startsWith('/api/'))return;
 const page=req.mode==='navigate'||req.destination==='document';
 event.respondWith((async()=>{
   const cache=await caches.open(CACHE);
   if(page){
     try{
       const fresh=await fetch(req);
       // A transient origin/server failure must not replace a working offline
       // app shell with a blank 5xx page. Keep real 4xx responses visible so
       // missing routes/assets are not disguised as successful app loads.
       if(fresh.status>=500){
         const cached=(await cache.match(req))||(await cache.match('./index.html'));
         if(cached)return cached;
       }
       if(fresh.ok)event.waitUntil(cache.put(req,fresh.clone()).catch(()=>{}));
       return fresh;
     }catch(_){return (await cache.match(req))||(await cache.match('./index.html'))||Response.error();}
   }
   try{const fresh=await fetch(req);if(fresh.ok&&/^(basic|default)$/.test(fresh.type))event.waitUntil(cache.put(req,fresh.clone()).catch(()=>{}));return fresh;}catch(_){return (await cache.match(req))||Response.error();}
 })());
});
