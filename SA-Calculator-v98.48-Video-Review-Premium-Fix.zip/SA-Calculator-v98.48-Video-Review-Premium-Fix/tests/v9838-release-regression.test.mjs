import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");
test("v98.38 release identity is synchronized across package, cache and Android workflow",()=>{
 const pkg=JSON.parse(read("package.json")); assert.equal(pkg.version,"1.98.48-v98.48");
 const sw=read("service-worker.js"); assert.match(sw,/sa-calculator-v98-48-video-layout-fix/);
 const wf=read(".github/workflows/main.yml"); assert.match(wf,/1\.98\.48-v98\.48/); assert.match(wf,/1098048/);
 assert.equal(wf,read("SA-Calculator-v98.48-Android-Workflow.yml"));
});
test("v98.38 stylesheet is linked, precached and required in Android bundle",()=>{
 assert.match(read("index.html"),/assets\/css\/rebuild-v98\.39\.css/);
 assert.match(read("service-worker.js"),/assets\/css\/rebuild-v98\.39\.css/);
 assert.match(read("scripts/prepare-android-web.mjs"),/assets\/css\/rebuild-v98\.39\.css/);
});
test("v98.38 adds keyboard focus visibility and narrow form containment",()=>{
 const css=read("assets/css/rebuild-v98.38.css");
 assert.match(css,/select:focus-visible/); assert.match(css,/button:focus-visible/);
 assert.match(css,/@media \(max-width: 340px\)/); assert.match(css,/flex-wrap: wrap/);
});
test("all 18 source-defined screen IDs remain present",()=>{
 const ids=JSON.parse(read("design-reference/18-screen-inventory.json")).map(x=>x.id);
 const html=read("index.html"); for(const id of ids) assert.match(html,new RegExp(`id=["']screen-${id}["']`));
 assert.equal(new Set(ids).size,18);
});
